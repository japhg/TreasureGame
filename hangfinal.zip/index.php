<?php
 
require 'controller.php';


?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>

<body>

<audio id="player" autoplay loop>
    <source src="sounds/tre1.mp3" type="audio/mp3">
</audio>

</body>
</html>