These images are released under the Creative Commons Licence.
http://creativecommons.org/licenses/by/4.0/legalcode

Copyright (c) 2015, by Marc Oliveras Galvez All rights reserved.
Website: Hosting 96 - ho96.com
Email: oligalma@gmail.com