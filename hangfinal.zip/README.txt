Copyright (c) 2021, by Marc Oliveras Galvez
Website: http://oligalma.com
Email: admin@oligalma.com

Third-party resources
=====================
bg.jpg --> https://www.freeimages.com/photo/wood-texture-1193381
applause.mp3 --> https://freesound.org/people/Charel%20Sytze/sounds/35490
blop.mp3 --> https://freesound.org/people/cfork/sounds/8001
boo.mp3 --> https://freesound.org/people/freki3333/sounds/131594
